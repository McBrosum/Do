#ifndef __CLASSES__
#define __CLASSES__
struct Stats;
struct Things;

class Display;
class Xp;
class Files;
class Get_stuff;
class Erase;
class Tools;
#endif