/*
        To do:
Custom xp option
Prestige level
    modifies how much xp you earn
Get user name
add 'x' to answer in int main
skip page function
add Sleep() function
fix get_stats()
add a list of what each command does in the int main
cout "command" when the user is in the int main
add get_name() function
fix the level bar in the check level function

        Plan:

Each time you finish a thing in the to do list,
you add a certain amount of experience based on the difficulty of the thing finished.

    Types of xp:
Small thing = 1xp
Medium thing = 3xp
Big thing = 10xp
Mega thing = 50xp
Custom thing = xxp

    Levels:
lvl 1 = 6xp
lvl 2 = lvl^()xp;
lvl 3 =

    Prestige level
After you reach a certain level, you level up your prestige
Your prestige level will modify the variable that multiplys the xp you earn after completing things.

    Rewards:
IDK yet
Look up how to reward yourself
*/
#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <string>
#include <windows.h>

using namespace std;

struct Stats {
    double level = 1.0;
    double xp = 0.0;
    double level_bar = 6.0;
    double prestige = 1.0;

    string prestige_title = "Noob";
    string username = "";

    bool ifusername = 0;
};

void display_stats(Stats stats);
Stats add_experience(Stats stats);
Stats check_level(Stats stats);
void update_folder(Stats stats);
Stats get_stats();
void reset_stats();
void skip_page();
Stats get_name();

//for opening files
const string filename = "level V1.1.txt";

int main()
{
    Stats stats;
    stats = get_stats();

    //get name if user does not have a name
    if (stats.ifusername = false)
    {
        stats = get_name();
        update_folder(stats);
    }

    //start program
    while (true)
    {
        char answer = ' ';
        display_stats(stats);

        cout << "Command list\n"
            << "a - Add things\n"
            << "l - leave\n"
            << "x - Erase all data\n\n";
        cout << "Command: ";
        cin >> answer;

        if (answer == 'a')
        {
            stats = add_experience(stats);
            stats = check_level(stats);
            update_folder(stats);
            continue;
        }
        else if (answer == 'l')
        {
            cout << "\nBye!\n\n\n";
            return 0;
        }
        else if (answer == 'x')
        {
            while (true)
            {
                char answer2 = ' ';
                cout << "Are you sure you want to erase all data? (y/n)\n";
                Sleep(1000);
                cin >> answer2;

                if (answer2 == 'y')
                {
                    reset_stats();
                    stats = get_stats();
                    break;
                }
                else if (answer2 == 'n')
                {
                    break;
                }
                else
                {
                    cout << "Please enter 'y', 'n', or 'x'.\n";
                    cin.clear();
                    cin.ignore(10000, '\n');
                }
            }
        }
        else
        {
            cout << "Dude, this is your own program.\n";
            cin.clear();
            cin.ignore(10000, '\n');
            continue;
        }
    }
    return 0;
}

void display_stats(Stats stats)
{
    skip_page();
    cout << "You are level " << stats.level << ".\n";
    cout << setprecision(3);
    cout << "You have " << stats.xp << '/' << stats.level_bar << " experience.\n";
    cout << "You need " << (stats.level_bar - stats.xp) << " more experience to level up.\n";
    cout << stats.username << " the " << stats.prestige_title << ". Prestige lvl: " << stats.prestige << "\n\n\n";
}

Stats add_experience(Stats stats)
{
    double smallxp, medium, large, mega, custom = 0.0;
    double new_xp = 0.0;

    //get xp
    //get small
    while (true)
    {
        cout << "# of small things: ";

        while (!(cin >> smallxp))
        {
            cout << "Please enter a number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }

        if (smallxp < 0)
        {
            cout << "Please enter a positive number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }
        else
        {
            break;
        }
    }

    //get medium
    while (true)
    {
        cout << "# of medium things: ";

        while (!(cin >> medium))
        {
            cout << "Please enter a number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }

        if (medium < 0)
        {
            cout << "Please enter a positive number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }
        else
        {
            break;
        }
    }

    //get large
    while (true)
    {
        cout << "# of large things: ";

        while (!(cin >> large))
        {
            cout << "Please enter a number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }

        if (large < 0)
        {
            cout << "Please enter a positive number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }
        else
        {
            break;
        }
    }

    //get mega
    while (true)
    {
        cout << "# of mega things: ";

        while (!(cin >> mega))
        {
            cout << "Please enter a number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }

        if (mega < 0)
        {
            cout << "Please enter a positive number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }
        else
        {
            break;
        }
    }

    //get custom
    while (true)
    {
        cout << "Custom xp count: ";

        while (!(cin >> custom))
        {
            cout << "Please enter a number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }

        if (custom < 0)
        {
            cout << "Please enter a positive number.\n";
            cin.ignore(10000, '\n');
            cin.clear();
        }
        else
        {
            break;
        }
    }

    //update stats
    new_xp = (smallxp + (medium * 3.0) + (large * 10.0) + (mega * 50.0) + custom) * stats.prestige;
    stats.xp += new_xp;
    return stats;
}

Stats check_level(Stats stats)
{
    double modifier = 1.0;

    //runs while leveling up is true
    while (true)
    {
        modifier = 1 + (stats.level / 75);                      //set modifier

        while (true)
        {
            if (stats.xp >= stats.level_bar)
            {
                stats.level += 1.0;                             //level up
                stats.xp -= stats.level_bar;                    //subtract for completing a level
                stats.level_bar = pow(stats.level_bar, modifier);   //set the amount of xp needed to level up for the next time
            }
            else if (stats.xp < stats.level_bar)
            {
                break;                                          //if I don't level up
            }
        }
        break;
    }

    //update prestige
    if (stats.level >= 5)
    {
        if (stats.level >= 20)  //*4
        {
            if (stats.level >= 60)  //*3
            {
                if (stats.level >= 120) //*2
                {
                    if (stats.level >= 180) //*1.5
                    {
                        stats.prestige = 6;
                        cout << stats.prestige_title << "Titan";
                        cout << "Prestige level up!" << stats.prestige_title << "\n\n";
                        cin.ignore();
                        return stats;
                    }
                    stats.prestige = 5;
                    stats.prestige_title = "Champion";
                    cout << "Prestige level up!" << stats.prestige_title << "\n\n";
                    cin.ignore();
                    return stats;
                }
                stats.prestige = 4;
                stats.prestige_title = "Knight";
                cout << "Prestige level up! " << stats.prestige_title << "\n\n";
                cin.ignore();
                return stats;
            }
            stats.prestige = 3;
            stats.prestige_title = "Squire";
            cout << "Prestige level up! " << stats.prestige_title << "\n\n";
            cin.ignore();
            return stats;
        }
        stats.prestige = 2;
        stats.prestige_title = "Novice";
        cout << "Prestige level up! " << stats.prestige_title << "\n\n";
        cin.ignore();
        return stats;
    }
    return stats;
}

void update_folder(Stats stats)
{
    //clear file
    ofstream stat_file;
    stat_file.open(filename, ios::out);
    if (stat_file)
    {
        stat_file.close();
    }

    //update file
    stat_file.open(filename, ios::app);
    if (stat_file)
    {
        stat_file << stats.level << '\t'
            << stats.xp << '\t'
            << stats.level_bar << '\t'
            << stats.prestige << '\t'
            << stats.prestige_title << '\t'
            << stats.username << '\t'
            << stats.ifusername;
        stat_file.close();
    }
    else
    {
        cout << "Couldn't open file. :/\n\n";
        stat_file.close();
    }
    skip_page();
    cout << "Saved!\n\n\n\n\n\n\n\n";
    Sleep(1000);
}

Stats get_stats()
{
    Stats stats;
    ifstream stat_file;
    stat_file.open(filename);
    if (stat_file)
    {
        stat_file >> stats.level
            >> stats.xp
            >> stats.level_bar
            >> stats.prestige
            >> stats.prestige_title
            >> stats.username
            >> stats.ifusername;
        stat_file.close();
    }
    return stats;
}

void reset_stats()
{
    Stats stats;

    //update stats structure
    stats.level = 1;
    stats.xp = 0;
    stats.level_bar = 6;
    stats.prestige = 1.0;

    stats.prestige_title = "Noob";
    stats.username = "";

    stats.ifusername = 0;

    //clear file
    ofstream stat_file;
    stat_file.open(filename, ios::out);
    if (stat_file)
    {
        stat_file.close();
    }

    //add default data
    stat_file.open(filename, ios::app);
    if (stat_file)
    {
        stat_file << stats.level << '\t'
            << stats.xp << '\t'
            << stats.level_bar << '\t'
            << stats.prestige << '\t'
            << stats.prestige_title << '\t'
            << stats.username << '\t'
            << stats.ifusername;
        stat_file.close();
    }
    cout << "Data erased!\n\n";
    Sleep(1500);
    skip_page();

    cin.ignore();                   //clear the enter inputed when answering yes
    stats = get_name();
    update_folder(stats);
    skip_page();
}

void skip_page()
{
    for (int i = 0; i < 20; i++)
    {
        cout << "\n\n\n\n";
    }
}

Stats get_name()
{
    Stats stats;
    //get username if user doesn't have a name
    if (stats.ifusername == 0)
    {
        while (true)
        {
            cout << "What is your name?\n\n\t";
            getline(cin, stats.username);

            if (stats.username == "")
            {
                cout << "Please enter a name.\n";
                cin.clear();
                cin.ignore(10000, '\n');
                continue;
            }
            break;
        }
        stats.ifusername = 1;
        skip_page();
        Sleep(500);
    }
    return stats;
}