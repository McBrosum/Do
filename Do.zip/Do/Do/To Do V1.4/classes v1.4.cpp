//all functions are in classes

#include "Classes V1.4.h"

#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <string>
#include <windows.h>
using namespace std;

//structures
struct Stats {
    double level = 1.0;
    double xp = 0.0;
    double level_bar = 6.0;
    double prestige = 1.0;
    double total_xp = 0.0;
    double xp_earn_prev = 0.0;
    double avg_xp_earn = 0.0;

    int time_user_enter = 0;

    bool ifusername = 0;

    string prestige_title = "Noob";
    string username = "";
};

struct Things {
    int small_count = 0;
    int medium_count = 0;
    int large_count = 0;
    int mega_count = 0;
    int custom_count = 0;

    int total_count = 0;
};


//classes
class Tools {
private:
    Stats stats;
    Things things;
public:
    void skip_page()
    {
        for (int i = 0; i < 20; i++)
        {
            cout << "\n\n\n\n";
        }
    }

    void help()
    {
        cout << "HELP\n\n";

        cout << "General:\n"
            << "As you complete things on the to do list,\n"
            << "you will earn XP based on the difficulty of the task completed.\n"
            << "You level up when you reached the required XP amount.\n"
            << "When you get to a certain level, you prestige will level up.\n\n"
            << "You can erase one stat or thing, change your name, or clear all data.\n"
            << "Press enter to continue.\n";
        cin.ignore();

        cout << "XP:\n"
            << "Small = 1 XP\n"
            << "Medium = 3 XP\n"
            << "Large = 10 XP\n"
            << "Mega = 50 XP\n"
            << "Custom = Any number XP\n\n";
        cin.ignore();

        cout << "Levels:\n"
            << "Level 1 = 6 XP\n"
            << "Level 2 = 6 * (1 + (level / 65))\n"
            << "Level 3 = lvl2 * (1 + (level / 65))\n\n";
        cin.ignore();

        cout << "Prestige:\n"
            << "Prestige title is the rank name that you are in.\n"
            << "Prestige level is the multiplier for xp.\n"
            << "\tEx. Prestige lvl = 2, xp = 10.\n"
            << "Prestige lvl * 10 XP = 20 XP\n";
        cin.ignore();
        skip_page();
        Sleep(250);
    }

    void tips()
    {
        cout << "Here are some tips to get things done!\n\n";
        cin.ignore();
        cout << "1: Make it obvious\n";
        Sleep(150);
        cout << "2: Make it attractive\n";
        Sleep(150);
        cout << "3: Make it satisfying\n";
        Sleep(150);
        cout << "4: Make it rewarding\n\n";
        Sleep(150);
        cin.ignore();
        cout << "These are some basic tips from Atomic Habits by James Clear.\n";
        cin.ignore();
    }
};

class Files {
private:
    Stats stats;
    Things things;
    const string filename1 = "level v1.4.txt";
    const string filename2 = "things v1.4.txt";
    Tools tools;
public:
    void update_files(Stats stats, Things things, bool icon)
    {
        //clear stat file
        ofstream stat_file;
        stat_file.open(filename1, ios::out);
        if (stat_file)
        {
            stat_file.close();
        }

        //update stat file
        stat_file.open(filename1, ios::app);
        if (stat_file)
        {
            stat_file << stats.level << '\t'
                << stats.xp << '\t'
                << stats.level_bar << '\t'
                << stats.prestige << '\t'
                << stats.prestige_title << '\t'
                << stats.username << '\t'
                << stats.ifusername << '\t'
                << stats.total_xp << '\t'
                << stats.xp_earn_prev << '\t'
                << stats.avg_xp_earn << '\t'
                << stats.time_user_enter;
            stat_file.close();
        }
        else
        {
            cout << "Couldn't open file. :/\n\n";
            stat_file.close();
        }


        //clear thing file
        stat_file.open(filename2, ios::out);
        if (stat_file)
        {
            stat_file.close();
        }

        //update thing file
        stat_file.open(filename2, ios::app);
        if (stat_file)
        {
            stat_file << things.small_count << '\t'
                << things.medium_count << '\t'
                << things.large_count << '\t'
                << things.mega_count << '\t'
                << things.custom_count << '\t'
                << things.total_count;
            stat_file.close();
        }
        else
        {
            cout << "Couldn't open file. :/\n\n";
            stat_file.close();
        }

        //display "Saved!" if the icon == true
        if (icon == true)
        {
            tools.skip_page();
            cout << "Saved!\n\n\n\n\n\n\n\n";
            Sleep(750);
            tools.skip_page();
        }
    }
};

class Display {
private:
    Stats stats;
    Things things;
    Tools tools;
public:
    void display_everything(Stats stats, Things things)
    {
        tools.skip_page();

        //display
        display_stats(stats);
        cout << '\n';
        display_things(things);

        //exit
        Sleep(500);
        cin.ignore();
        tools.skip_page();
    }

    void display_stats(Stats stats)
    {
        //title for stats
        cout << "STATS\n";
        //total xp
        cout << "You have earned " << stats.total_xp << " total xp.\n";
        //level
        cout << "You are level " << stats.level << ".\n";
        //set decimal places
        cout << setprecision(2) << fixed;
        //xp and level bar
        cout << "You have " << stats.xp << '/' << stats.level_bar << " experience.\n";
        //experience needed
        cout << "You need " << (stats.level_bar - stats.xp) << " more experience to level up.\n";
        //prestige and prestige title
        cout << stats.username << " the " << stats.prestige_title << ". Prestige lvl: " << stats.prestige << '\n';
        //xp earned last time
        cout << "You earned " << stats.xp_earn_prev << " experience last time.\n";
        //average xp earned
        cout << "Your average amount of xp earned each time you enter something is " << stats.avg_xp_earn << " experience.\n";
    }

    void display_things(Things things)
    {
        //title for things
        cout << "THINGS\n";
        //total things
        cout << "Total things completed: " << things.total_count << '\n';
        //small things
        cout << "Small things completed: " << things.small_count << '\n';
        //medium things
        cout << "Medium things completed: " << things.medium_count << '\n';
        //large things
        cout << "Large things completed: " << things.large_count << '\n';
        //mega things
        cout << "Mega things completed: " << things.mega_count << '\n';
        //custom things
        cout << "Custom things completed: " << things.custom_count << '\n';
    }
};

class Xp {
private:
    Stats stats;
    Things things;
    Files files;
    Tools tools;
public:
    void add_experience(Stats stats, Things things)
    {
        int smallxp = 0;
        int medium = 0;
        int large = 0;
        int mega = 0;
        int level = 0;

        double custom = 0.0;
        double xp_earned = 0.0;

        //let user know that they can op out
        cout << "Press '-1' to cancel adding experience.\n";

        while (true)
        {
            //get xp
            //get small
            while (true)
            {
                cout << "# of small things: ";

                while (!(cin >> smallxp))
                {
                    cout << "Please enter a number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }

                if (smallxp == -1)
                {
                    break;
                }
                else if (smallxp < 0)
                {
                    cout << "Please enter a positive number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }
                else
                {
                    //update things structure
                    things.small_count += smallxp;
                    break;
                }
            }
            //-1 is if the user cancels adding experience
            if (smallxp == -1)
            {
                tools.skip_page();
                break;
            }

            //get medium
            while (true)
            {
                cout << "# of medium things: ";

                while (!(cin >> medium))
                {
                    cout << "Please enter a number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }

                if (medium == -1)
                {
                    break;
                }
                else if (medium < 0)
                {
                    cout << "Please enter a positive number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }
                else
                {
                    //update things structure
                    things.medium_count += medium;
                    break;
                }
            }
            if (medium == -1)
            {
                tools.skip_page();
                break;
            }

            //get large
            while (true)
            {
                cout << "# of large things: ";

                while (!(cin >> large))
                {
                    cout << "Please enter a number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }

                if (large == -1)
                {
                    break;
                }
                else if (large < 0)
                {
                    cout << "Please enter a positive number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }
                else
                {
                    //update things structure
                    things.large_count += large;
                    break;
                }
            }
            if (large == -1)
            {
                tools.skip_page();
                break;
            }

            //get mega
            while (true)
            {
                cout << "# of mega things: ";

                while (!(cin >> mega))
                {
                    cout << "Please enter a number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }

                if (mega == -1)
                {
                    break;
                }
                else if (mega < 0)
                {
                    cout << "Please enter a positive number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }
                else
                {
                    //update things structure
                    things.mega_count += mega;
                    break;
                }
            }
            if (mega == -1)
            {
                tools.skip_page();
                break;
            }

            //get level
            while (true)
            {
                cout << "# of levels: ";

                while (!(cin >> level))
                {
                    cout << "Please enter a number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }

                if (level == -1)
                {
                    break;
                }
                else if (level < 0)
                {
                    cout << "Please enter a positive number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }
                else
                {
                    break;
                }
            }
            if (level == -1)
            {
                tools.skip_page();
                break;
            }

            //get custom
            while (true)
            {
                cout << "Custom xp count: ";

                while (!(cin >> custom))
                {
                    cout << "Please enter a number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }

                if (custom == -1)
                {
                    break;
                }
                else if (custom < 0)
                {
                    cout << "Please enter a positive number.\n";
                    cin.ignore(10000, '\n');
                    cin.clear();
                }
                else
                {
                    break;
                }
            }
            if (custom == -1)
            {
                tools.skip_page();
                break;
            }


            //update xp and total_xp
            xp_earned = (smallxp + (medium * 3) + (large * 10) + (mega * 50) + custom) * stats.prestige;
            stats.xp += xp_earned;
            stats.total_xp += xp_earned;

            //update thing counter
            things.total_count += smallxp + medium + large + mega;

            //if the user entered a custom xp count
            if (custom != 0)
            {
                ++things.custom_count;
                ++things.total_count;
            }

            //update level if the user added levels
            if (stats.level != 0)
            {
                stats.level += level;
                double modifier = 1 + (stats.level / 50);
                stats.level_bar = 6 * modifier;
            }

            //update xp_earn_prev for the next time
            stats.xp_earn_prev = xp_earned;

            //update times user entered
            stats.time_user_enter++;

            //update average xp
            stats.avg_xp_earn = stats.total_xp / stats.time_user_enter;

            //end here by updating both structures
            files.update_files(stats, things, true);
            break;
        }
    }

    Stats level_up(Stats stats)
    {
        double modifier = 1.0;

        //runs while leveling up is true
        while (true)
        {
            while (true)
            {
                //set modifier
                modifier = 1 + (stats.level / 50);

                //if enough xp to level up
                if (stats.xp >= stats.level_bar)
                {
                    //level up
                    stats.level += 1.0;
                    //subtract for completing a level
                    stats.xp -= stats.level_bar;
                    //set the amount of xp needed to level up for the next time
                    stats.level_bar = 6 * modifier;
                }
                else if (stats.xp < stats.level_bar)
                {
                    //if not enough xp
                    break;
                }
            }
            break;
        }

        //update prestige
        //level 2 prestige
        if (stats.level >= 5)
        {
            //level 3 prestige
            if (stats.level >= 20)  //5 * 4
            {
                //level 4 prestige
                if (stats.level >= 60)  //20 * 3
                {
                    //level 5 prestige
                    if (stats.level >= 120) //60 * 2
                    {
                        //level 6 prestige
                        if (stats.level >= 180) //120 * 1.5
                        {
                            if (stats.prestige_title == "Titan")
                            {
                                return stats;
                            }
                            stats.prestige = 6;
                            cout << stats.prestige_title << "Titan";
                            cout << "Prestige level up!" << stats.prestige_title << "\n\n";
                            cin.ignore();
                            cin.ignore();
                            return stats;
                        }
                        if (stats.prestige_title == "Champion")
                        {
                            return stats;
                        }
                        stats.prestige = 5;
                        stats.prestige_title = "Champion";
                        cout << "Prestige level up!" << stats.prestige_title << "\n\n";
                        cin.ignore();
                        cin.ignore();
                        return stats;
                    }
                    if (stats.prestige_title == "Knight")
                    {
                        return stats;
                    }
                    stats.prestige = 4;
                    stats.prestige_title = "Knight";
                    cout << "Prestige level up! " << stats.prestige_title << "\n\n";
                    cin.ignore();
                    cin.ignore();
                    return stats;
                }
                if (stats.prestige_title == "Squire")
                {
                    return stats;
                }
                stats.prestige = 3;
                stats.prestige_title = "Squire";
                cout << "Prestige level up! " << stats.prestige_title << "\n\n";
                cin.ignore();
                cin.ignore();
                return stats;
            }
            if (stats.prestige_title == "Novice")
            {
                return stats;
            }
            stats.prestige = 2;
            stats.prestige_title = "Novice";
            cout << "Prestige level up! " << stats.prestige_title << "\n\n";
            cin.ignore();
            cin.ignore();
            return stats;
        }
        return stats;
    }
};

class Erase {
private:
    Stats stats;
    Things things;
    const string filename1 = "level v1.4.txt";
    const string filename2 = "things v1.4.txt";
    Tools tools;
    Files files;
    Display display;
public:
    void reset()
    {
        //use default stats
        Stats stats;
        stats.time_user_enter = 0;
        Things things;

        //cin.ignore to cancel the enter
        cin.ignore();

        //clear stat file
        ofstream stat_file;
        stat_file.open(filename1, ios::out);
        if (stat_file)
        {
            stat_file.close();
        }
        else
        {
            cout << "Couldn't Open File.\n";
        }

        //add default data to stat file
        stat_file.open(filename1, ios::app);
        if (stat_file)
        {
            stat_file << stats.level << '\t'
                << stats.xp << '\t'
                << stats.level_bar << '\t'
                << stats.prestige << '\t'
                << stats.prestige_title << '\t'
                << stats.username << '\t'
                << stats.ifusername << '\t'
                << stats.total_xp << '\t'
                << stats.xp_earn_prev << '\t'
                << stats.avg_xp_earn << '\t'
                << stats.time_user_enter;
            stat_file.close();
        }
        else
        {
            cout << "Couldn't Open File.\n";
        }

        //clear thing file
        ofstream thing_file;
        thing_file.open(filename2, ios::out);
        if (thing_file)
        {
            thing_file.close();
        }
        else
        {
            cout << "Couldn't open file.\n";
        }

        //add default data to thing file
        thing_file.open(filename2, ios::app);
        if (stat_file)
        {
            stat_file << things.small_count << '\t'
                << things.medium_count << '\t'
                << things.large_count << '\t'
                << things.mega_count << '\t'
                << things.total_count;
            thing_file.close();
        }
        else
        {
            cout << "Couldn't open file.\n";
        }

        //reset complete
        cout << "Reset successful!\n\n";
        Sleep(1500);
        tools.skip_page();
        files.update_files(stats, things, false);
        tools.skip_page();
    }

    Stats default_stats()
    {
        Stats stats;
        return stats;
    }

    Things default_things()
    {
        Things things;
        return things;
    }

    Stats erase_one_stat(Stats stats)
    {
        char choice = ' ';

        //display stats
        tools.skip_page();
        display.display_stats(stats);

        while (true)
        {
            cout << "\nWhich stat would you like to erase?\n"
                << "a: Level\n"
                << "b: XP\n"
                << "c: Total XP\n"
                << "d: Prestige\n"
                << "Command: ";
            cin >> choice;

            if (choice == 'a')
            {
                stats.level = 1;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'b')
            {
                stats.xp = 0;
                stats.level_bar = 6;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'c')
            {
                stats.total_xp = 0;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'd')
            {
                stats.prestige = 1;
                stats.prestige_title = "Noob";
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else
            {
                cout << "Please enter 'a', 'b', 'c', or 'd'.\n";
                cin.clear();
                cin.ignore(10000, '\n');
                continue;
            }
        }
        return stats;
    }

    Things erase_one_thing(Things things)
    {
        char choice = ' ';

        //display things
        tools.skip_page();
        display.display_things(things);

        while (true)
        {
            cout << "\nWhich thing you like to erase?\n"
                << "a: Small things\n"
                << "b: Medium things\n"
                << "c: Large things\n"
                << "d: Mega things\n"
                << "e: Custom things\n"
                << "f: Total things\n"
                << "Command: ";
            cin >> choice;

            if (choice == 'a')
            {
                things.small_count = 0;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'b')
            {
                things.medium_count = 0;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'c')
            {
                things.large_count = 0;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'd')
            {
                things.mega_count = 0;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'e')
            {
                things.custom_count = 0;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else if (choice == 'f')
            {
                things.total_count = 0;
                cout << "Erased!\n";
                Sleep(250);
                tools.skip_page();
                break;
            }
            else
            {
                cout << "Please enter 'a', 'b', 'c', 'd', 'e', or 'f'.\n\n"
                    << "Press enter to continue: ";
                cin.clear();
                cin.ignore(10000, '\n');
                cin.ignore();
                continue;
            }
        }
        return things;
    }
};

class Get_stuff {
private:
    Stats stats;
    Things things;
    const string filename1 = "level v1.4.txt";
    const string filename2 = "things v1.4.txt";
    Tools tools;
public:
    Stats get_stats(Stats stats)
    {
        ifstream stat_file;
        stat_file.open(filename1);
        if (stat_file)
        {
            stat_file >> stats.level
                >> stats.xp
                >> stats.level_bar
                >> stats.prestige
                >> stats.prestige_title
                >> stats.username
                >> stats.ifusername
                >> stats.total_xp
                >> stats.xp_earn_prev
                >> stats.avg_xp_earn
                >> stats.time_user_enter;
            stat_file.close();
        }
        return stats;
    }

    Things get_things(Things things)
    {
        ifstream thing_file;
        thing_file.open(filename2);
        if (thing_file)
        {
            thing_file >> things.small_count
                >> things.medium_count
                >> things.large_count
                >> things.mega_count
                >> things.custom_count
                >> things.total_count;
            thing_file.close();
        }
        return things;
    }

    string get_name(Stats stats)
    {
        //get username if user doesn't have a name
        while (true)
        {
            cout << "What is your name?\n\n\t";
            getline(cin, stats.username);

            if (stats.username == "")
            {
                cout << "Please enter a name.\n";
                continue;
            }
            break;
        }
        stats.ifusername = 1;
        tools.skip_page();
        Sleep(500);
        return stats.username;
    }
};