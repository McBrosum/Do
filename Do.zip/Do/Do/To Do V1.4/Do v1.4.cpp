#include <iostream>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <string>
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "Classes V1.4.h"
#include "Classes V1.4.cpp"
using namespace std;

int main()
{
    //class objects
    Display display;
    Xp xp;
    Files files;
    Get_stuff get_stuff;
    Erase erase;
    Tools tools;

    //declare structures
    Stats stats;
    Things things;

    //variables
    char choice;

    //update structures
    stats = get_stuff.get_stats(stats);
    things = get_stuff.get_things(things);

    //get name if user does not have a name
    if (stats.ifusername == 1)
    {
        stats.username = get_stuff.get_name(stats);
        files.update_files(stats, things, true);
    }

    //main menu
    while (true)
    {
        char answer;

        cout << "Command list\n"
            << "a: Add things\n"
            << "c: Change name\n"
            << "s: Show stats\n"
            << "h: Help\n"
            << "t: Tips\n"
            << "l: Leave\n"
            << "e: Erase one stat or thing\n"
            << "x: Erase all data\n\n";
        cout << "Command: ";
        cin >> answer;

        //cin.ignore() at the beggining of each choice cancels out
        //the enter inputed by the user when they pick an option
        // 
        //menu portal
        switch (answer)
        {
        case 'a':
        {
            cin.ignore();
            xp.add_experience(stats, things);
            stats = get_stuff.get_stats(stats);
            things = get_stuff.get_things(things);
            stats = xp.level_up(stats);
            files.update_files(stats, things, false);
            break;
        }
        case 'c':
        {
            cin.ignore();
            stats.username = get_stuff.get_name(stats);
            files.update_files(stats, things, true);
            break;
        }
        case 's':
        {
            cin.ignore();
            display.display_everything(stats, things);
            break;
        }
        case 'h':
        {
            cin.ignore();
            tools.skip_page();
            tools.help();
            break;
        }
        case 't':
        {
            cin.ignore();
            tools.tips();
            tools.skip_page();
            break;
        }
        case 'l':
        {
            cout << "\nBye!\n\n\n";
            Sleep(500);
            return 0;
        }
        case 'e':
        {
            cin.ignore();
            while (true)
            {
                cout << "Would you like to erase a stat or thing? (s/t)\n";
                cin >> choice;

                if (choice == 's')
                {
                    stats = erase.erase_one_stat(stats);
                    files.update_files(stats, things, false);
                    break;
                }
                else if (choice == 't')
                {
                    things = erase.erase_one_thing(things);
                    files.update_files(stats, things, false);
                    break;
                }
                else
                {
                    cout << "Please enter one of the following options.\n";
                    cin.clear();
                    cin.ignore(10000, '\n');
                    continue;
                }
            }
            break;
        }
        case 'x':
        {
            cin.ignore();
            while (true)
            {
                char answer2 = ' ';
                cout << "Are you sure you want to erase all data? (y/n)\n";
                Sleep(1000);
                cin >> answer2;

                if (answer2 == 'y')
                {
                    erase.reset();
                    stats = erase.default_stats();
                    things = erase.default_things();
                    stats.username = get_stuff.get_name(stats);
                    files.update_files(stats, things, true);
                    break;
                }
                else if (answer2 == 'n')
                {
                    tools.skip_page();
                    break;
                }
                else
                {
                    cout << "Please enter 'y' or 'n'.\n";
                    cin.clear();
                    cin.ignore(10000, '\n');
                    continue;
                }
            }
            break;
        }
        default:
        {
            cout << "Please enter one of the following options:\n"
                << "a\nc\ns\nh\nl\ne\nx\n\n"
                << "Press enter to continue: ";
            cin.clear();
            cin.ignore(10000, '\n');
            cin.ignore();
            tools.skip_page();
            continue;
        }
        }
    }
    return 0;
}